from celery import shared_task
import bson
from polls.models import Category,CouponApprOnListing,CouponMapping,Users,Vendors
from pymongo import MongoClient
import string
from django.db.models import manager
from django.db import connection
import datetime
import logging
cursor = connection.cursor()
null = None
from utils.mongo_tools import get_mongo_db
logger = logging.getLogger('MYAPP')
def divide_chunks(l,n):
    for i in range(0,len(l),n):
        yield l[i:i+n]

def maxDFCLimitCheck(coupon_code, coupon_id, coupon_end_date, listing , discount, coupon_discount_type, funded_by, droom_portion):
    try:
        if(funded_by=='seller' and droom_portion==0):
            return []

        deleted_listing_ids = ''
        category_id = listing['category_id']
        lid = listing['lid']
        listing_id = listing['_id']
        totalpayout = 0
        if(listing['total_payout_value']):
            totalpayout = listing['total_payout_value']
        sellingprice = 0
        if(listing['selling_price']):
            sellingprice = listing['selling_price']
        sfc = sellingprice - totalpayout
        if(coupon_discount_type=='percentage'):
            discount = int(discount*sellingprice/100)
        dfc = round(discount-sfc)
        dfc_percentage = round(dfc/sellingprice*100,2)
        category_data = {}
        to_remove_lids = ''
        category = Category.objects.filter(id=category_id).values('max_dfc_percentage','max_dfc_value','name','id')
        if category:
            for i in category:
                category_data['id'] = i['id']
                category_data['max_dfc_percentage'] = i['max_dfc_percentage']
                category_data['max_dfc_value'] = i['max_dfc_value']
                category_data['category_name'] = i['name']

        max_dfc_percentage = category_data['max_dfc_percentage']
        max_dfc_value = category_data['max_dfc_value']
        category_name = category_data['category_name']
        diff = 0
        logger.error(max_dfc_percentage)
        logger.error(dfc)
        if max_dfc_percentage > 0 or max_dfc_value > 0:
            count = CouponApprOnListing.objects.filter(coupon_code=coupon_code).filter(listing_id=listing_id).filter(dfc__gte=0).filter(status='approved').count()
            if count==0:
                count1 = CouponApprOnListing.objects.filter(coupon_code=coupon_code).filter(listing_id=listing_id).count()
            else:
                return []

            timestamp = datetime.datetime.now()
            params = {}
            params['coupon_id'] = coupon_id
            params['coupon_code'] = coupon_code
            params['listing_id'] = listing_id
            params['lid'] = lid
            params['discount'] = discount
            params['dfc'] = dfc
            params['dfc_percentage'] = dfc_percentage
            params['category_id'] = category_id
            params['status'] = 'pending_approval'
            params['category_name'] = category_name
            params['max_dfc_value'] = max_dfc_value
            params['max_dfc_percentage'] = max_dfc_percentage
            params['end_date'] = coupon_end_date
            params['created_at'] = timestamp
            params['updated_at'] = timestamp
            params['selling_price'] = sellingprice
            params['total_payout'] = totalpayout

            if dfc_percentage>max_dfc_percentage and max_dfc_percentage>0:
                deleted_listing_ids = lid
                diff = dfc_percentage - max_dfc_percentage
                params['exceeded'] = 'percentage'
                params['difference'] = diff

                if count1==0:
                    m = CouponApprOnListing(**params)
                    m.save()
                else:
                    CouponApprOnListing.objects.filter(coupon_code=coupon_code).filter(listing_id=listing_id).update(status='pending_approval',discount=discount,dfc=dfc,selling_price=sellingprice,total_payout=totalpayout)

            else:
                if dfc>max_dfc_value and max_dfc_value>0:
                    deleted_listing_ids = lid
                    diff = dfc - max_dfc_value
                    params['exceeded'] = 'amount'
                    params['difference'] = diff

                    if count1==0:
                        m = CouponApprOnListing(**params)
                        m.save()
                    else:
                        CouponApprOnListing.objects.filter(coupon_code=coupon_code).filter(listing_id=listing_id).update(
                            status='pending_approval', discount=discount, dfc=dfc, selling_price=sellingprice,
                            total_payout=totalpayout)

                else:
                    if count1!=0:
                        CouponApprOnListing.objects.filter(coupon_code=coupon_code).filter(listing_id=listing_id).delete()
                        to_remove_lids = lid

                    else:
                        return []

        result = {}
        result['code'] = 'success'
        result['deleted_listing_ids'] = deleted_listing_ids
        result['to_remove_lids'] = to_remove_lids
        logger.error(result)
        return result

    except Exception as e:
        logging.getLogger('MYAPP').error(repr(e))

@shared_task
def coupon_controller(valid,coupon_code,coupon_discount_type,discount):
    try:
        db = get_mongo_db('droom')
        where = {}
        wrong_city = 0
        cities = []
        where['status'] = 'active'
        where['quantity_available'] = {'$gte': 1}
        i = 0
        Coupon = db.coupons.find_one({"code": coupon_code})
        excludeLids = Coupon['exclude_lids']
        funded_by=Coupon['funded_by']
        strLids = []

        if valid['vehicle_type']:
            i = i + 1
            where['category_name'] = {'$eq': valid['vehicle_type']}

        if valid['make']:
            i = i + 1
            where['make'] = {'$eq': valid['make']}

        if (valid['model']):
            i = i + 1
            where['model'] = {'$eq': valid['model']}

        if (valid['year']):
            i = i + 1
            where['year'] = {'$eq': valid['year']}

        if (valid['trim']):
            i = i + 1
            where['trim'] = {'$eq': valid['trim']}

        if (valid['max_price']):
            i = i + 1
            where['selling_price'] = {'$lte': int(valid['max_price'])}

        if (valid['listing_id']):
            ids = []

            for id in valid['listing_id']:
                if (bson.objectid.ObjectId.is_valid(id)):
                    ids.append(bson.objectid.ObjectId(id))

            if ids:
                where['_id'] = {'$in': ids}

        if(valid['seller_id']):
            i = i + 1
            where['user_id'] = {'$in':valid['seller_id']}

        cities = valid['city']
        if cities:
            if valid['vehicle_condition'] and valid['vehicle_condition']=='new':
                if 'category_bucket' not in valid:
                    valid['category_bucket'] = ""
                if valid['category_bucket'] == 'asset':
                    where['dealer_locations'] = {'$in':cities}
                if valid['category_bucket'] == 'service':
                    if valid['category_bucket'] == 'merchandise':
                        where['servicable_locations'] = {'$in':cities}

            else:
                where['location'] = {'$in':cities}


        #where['deleted_at'] = {'$exists':'false'}
        deleted_listing_ids = []
        to_remove_lids = []
        if i>0 and not wrong_city:
            listings = db.cmp_listings.aggregate([
                {"$match": where},
                {"$project": {"_id": 1,'category_id':1,'total_payout_value':1,'selling_price':1,'lid':1,'user_id':1,'quick_sell':1}}
            ])
            user_ids = []
            temp_listings=list(listings)
            for i in temp_listings:
                user_ids.append(i['user_id'])
            params = {}
            f_vendors = []
            f_users = {}
            chunk = list(divide_chunks(user_ids,10000))
            for user_id in chunk:
                query = Users.objects.filter(id__in=user_id)
                users = {}
                for user in query:
                    users[user.id] = user.vendor_id

                vendor_ids = list(users.values())
                vendors_query = Vendors.objects.filter(id__in=vendor_ids).filter(suspended_dmp_status=1)
                vendors = []
                for v in vendors_query:
                    vendors.append(v.id)
                f_users = {**f_users,**users}
                f_vendors = f_vendors + vendors

            for listing in temp_listings:
                if(coupon_discount_type=="price_override"):
                    discount_new = listing['selling_price'] - discount
                    if(discount_new>=0):
                        discount = discount_new
                couponCheckList = maxDFCLimitCheck(coupon_code,Coupon['_id'],Coupon['end_date'],listing,discount,coupon_discount_type,funded_by,Coupon['droom_portion'])
                if not couponCheckList:
                    vendor_id = f_users[listing['user_id']]
                    if Coupon['applicable_for']!='both':
                        if Coupon['applicable_for']=='proseller':
                            if vendor_id==null:
                                continue

                    if vendor_id in f_vendors:
                        continue

                    if Coupon['applicable_on_listings']!='all':
                        if Coupon['applicable_on_listings']=='regular':
                            if 'quicksell' in listing and int(listing['quick_sell'])==1:
                                continue

                    elif Coupon['applicable_on_listings']=='quicksell':
                        if 'quicksell' in listing and int(listing['quick_sell']) == 0:
                            continue

                    mapping = CouponMapping.objects.filter(listing_id=listing['lid']).filter(coupon_id=Coupon['_id'])
                    timestamp = datetime.datetime.now()
                    if mapping:
                        mapping.status = 'R'
                        mapping.promotion_name=Coupon['promotion_name']
                        mapping.updated_at = timestamp
                        for m in mapping:
                            m.save()
                    else:
                        new_mapping = CouponMapping(coupon_id=Coupon['_id'],listing_id=listing['lid'],promotion_name=Coupon['promotion_name'],code=coupon_code,status='R',
                                                created_at=timestamp,updated_at=timestamp)
                        new_mapping.save()
                    continue
                else:
                    if couponCheckList['deleted_listing_ids']:
                        deleted_listing_ids.append(couponCheckList['deleted_listing_ids'])

                    if couponCheckList['to_remove_lids']:
                        to_remove_lids.append(couponCheckList['to_remove_lids'])

        else:
            b = 1



        result = {}
        result['deleted_listing_ids'] = deleted_listing_ids
        result['to_remove_lids'] = to_remove_lids
        return result

    except Exception as e:
        logging.getLogger('MYAPP').error(repr(e))
