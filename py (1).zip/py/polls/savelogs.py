from utils.mongo_tools import get_mongo_db
db = get_mongo_db('droom')
collection = db['coupon_history']
import datetime
import logging
logger = logging.getLogger('MYAPP')

def savelogs(coupon_id='',logs_for='',exclude_lids=''):
    try:
        time = datetime.datetime.now()
        my_dict = {"logs_for": logs_for, "user_id": "cron","created_at":time,"updated_at":time}
        logged_coupon = collection.find_one({"_id":coupon_id})
        if logged_coupon:
            my_dict['post_data'] = logged_coupon
            if exclude_lids:
                db.coupons.update_one({"_id": coupon_id}, {"$set": {"approval_lids": exclude_lids}})

            db.coupon_history.insert_one(my_dict)

        return


    except Exception as e:
        logging.getLogger('MYAPP').error(repr(e))