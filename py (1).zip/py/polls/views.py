from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.template import loader
from django.shortcuts import get_object_or_404
from django.shortcuts import render
from django.http import Http404
from django.urls import reverse
from django.conf import settings
import pymongo
from pymongo import MongoClient
from .tasks import coupon_controller
import json
import bson
from bson import ObjectId
from polls.models import CouponApprOnListing,CouponMapping
from django.core.serializers.json import DjangoJSONEncoder
import logging
from .savelogs import savelogs
from droomfinal import MONGO_CLIENT
from bson import ObjectId
import threading
import datetime
from django.shortcuts import render
import requests
#from django.core.cache.backends.base import DEFAULT_TIMEOUT
#from django.core.cache import cache
#CACHE_TTL = getattr(settings, 'CACHE_TTL', DEFAULT_TIMEOUT)
null = None
from utils.mongo_tools import get_mongo_db
logger = logging.getLogger('MYAPP')

def unique(l):
    list_set = set(l)
    unique_list = list(list_set)
    return unique_list

def Diff(list1,list2):
    return (list(set(list1)-set(list2)))

db = get_mongo_db('droom')
collection = db['coupons']
results={}
def threads(request):
    cashback_coupons = collection.find({"code":"DSCB1500"})
    jobs = []
    for i in cashback_coupons:
        data = {
            "coupon_code": i['code'],
            "coupon_id": i['_id'],
            "coupon_discount": i['discount'],
            "coupon_discount_type": i['discount_type'],
            "coupon_end_date": i['end_date'],
            "coupon_exclude_ids": []
        }

        thread = threading.Thread(target=validateCouponsApproval,args=(data,))
        jobs.append(thread)

    for j in jobs:
        j.start()

    for j in jobs:
        j.join()

    return HttpResponse("List Processing Complete")

def printcode(data):
    print(data['coupon_code']+" ")

def validateCouponsApproval(data):
    try:
        collection = db['coupons']
        coupon_code = data['coupon_code']
        deleted_listing_ids = []
        to_remove_lids = []
        result = {}
        if coupon_code:
            discount = data['coupon_discount']
            discount_percentage = 0
            updateCoupon = collection.find_one({"code":coupon_code})
            collection.update_one({"code": coupon_code}, {"$set": {"pending_approval": 2}})
            coupon_end_date = data['coupon_end_date']
            coupon_discount_type = data['coupon_discount_type']

            if(coupon_discount_type=="percentage"):
                discount_percentage = float(Coupon['coupon_discount'])
            coupon_valid_on = updateCoupon['valid_on']
            if(type(coupon_valid_on)==list):
                b = 0
                if updateCoupon['status']=='active' and ('commitment_fee' in updateCoupon['applies_to'] or 'selling_price' in updateCoupon['applies_to']):
                    collection.update_one({"code": coupon_code}, {"$set": {"pending_sync":2,"in_cmp_cron":1}})
                    savelogs(data['coupon_id'],"in_for_mapping")

                    to_be_updated = CouponMapping.objects.filter(coupon_id=data['coupon_id'])
                    CouponMapping.objects.filter(coupon_id=data['coupon_id']).update(status='I',updated_at=datetime.datetime.now())

                    for valid in coupon_valid_on:
                        logger.error(valid)
                        result = coupon_controller.delay(valid,coupon_code,coupon_discount_type,discount)
                        logger.error("Deepanshu")
                        logger.error(result)
                        deleted_listing_ids = deleted_listing_ids+result['deleted_listing_ids']
                        to_remove_lids = to_remove_lids+result['to_remove_lids']
                elif ('expired' in updateCoupon['status'] or 'inactive' in updateCoupon['status'])and ('commitment_fee' in updateCoupon['applies_to'] or 'selling_price' in updateCoupon['applies_to']):
                    CouponMapping.objects.filter(coupon_id=data['coupon_id']).update(status='D', updated_at=datetime.datetime.now())




            else:
              b = 1


        if b==0:
            if updateCoupon.__contains__('exclude_lids')=='false':
                updateCoupon['exclude_lids'] = []

            list_ans = updateCoupon['exclude_lids'] + result['deleted_listing_ids']
            list_ans = Diff(list_ans,result['to_remove_lids'])
            unique_list = unique(list_ans)
            myquery = {"code": coupon_code}
            newvalues = {"$set":{"exclude_lids":unique_list}}
            collection.update_one(myquery, newvalues)
            newvalues = {"$set":{"status": "active"}}
            collection.update_one(myquery, newvalues)
            CouponMapping.objects.filter(code=coupon_code).filter(status='I').update(status='D', updated_at=datetime.datetime.now())
            changedCoupon = collection.find_one({"code": coupon_code})
            if changedCoupon['exclude_lids']:
                CouponMapping.objects.filter(code=coupon_code).filter(listing_id__in=changedCoupon['exclude_lids']).delete()

        elif b==1:
            myquery = {"code": coupon_code}
            newvalues = {"$set": {"status": 'in_progress'}}
            collection.update_one(myquery, newvalues)
            CouponApprOnListing.objects.filter(coupon_code=coupon_code).delete()

        collection.update_one({"code": coupon_code}, {"$set": {"pending_approval": 0}})
        changeCoupon = collection.find({"_id":data['coupon_id']})
        collection.update_one({"_id": data['coupon_id']}, {"$set": {"pending_sync": 0}})
        if changeCoupon['wait_pending_sync']:
            collection.update_one({"_id": data['coupon_id']}, {"$set": {"pending_sync": 1}})
        collection.update_one({"_id": data['coupon_id']}, {"$set": {"wait_pending_sync": 0,"in_cmp_cron":0,"exception_there":0}})



    except Exception as e:

        savelogs(data['coupon_id'],'approval_exception')
        logging.getLogger('MYAPP').error(repr(e))

    finally:
        coupon_id = data['coupon_id']
        if coupon_id:
            db.coupons.update_one({"_id": coupon_id}, {"$set": {"pending_approval": 0}})



