import celery
from .celery import app as celery_app
import droomfinal.settings
import pymongo
MONGO_CLIENT = pymongo.MongoClient(host=settings.MONGO_HOST,port=settings.MONGO_PORT,username=settings.MONGO_USER,password=settings.MONGO_PASSWORD)
__all__ = ['celery_app']





